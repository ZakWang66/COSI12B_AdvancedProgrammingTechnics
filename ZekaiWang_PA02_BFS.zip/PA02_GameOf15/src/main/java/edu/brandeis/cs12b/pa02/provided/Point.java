package edu.brandeis.cs12b.pa02.provided;

public class Point {
	public int row, col;
	
	public Point(int row, int col) {
		this.row = row;
		this.col = col;
	}
}
